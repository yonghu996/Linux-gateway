# LGP1 探测协议规范（v1）

本协议是本次重建服务端与新 Probe Client 的共同规范。它不是旧 Probe Server v1.0.1 的兼容实现。

## 1. TCP / UDP 固定帧

每个请求和响应固定 78 字节，网络字节序（大端）。TCP 每个连接只发送一帧请求并读取一帧响应，随后关闭；UDP 每个数据报恰好一帧。

| 偏移 | 长度 | 字段 | 说明 |
|---:|---:|---|---|
| 0 | 4 | Magic | ASCII `LGP1` |
| 4 | 1 | Version | `0x01` |
| 5 | 1 | Type | 请求 `0x01`；响应 `0x02` |
| 6 | 8 | Timestamp | Unix 秒，uint64 大端 |
| 14 | 16 | Nonce | CSPRNG 随机 16 字节 |
| 30 | 16 | Client ID | 配置文件中 32 位小写十六进制 ID 解码后的 16 字节 |
| 46 | 32 | MAC | HMAC-SHA256，覆盖字节 `[0,46)` |

请求校验顺序：帧长度、Magic、Version、Type、来源 IP、Client ID、时间戳、HMAC、Nonce 防重放。失败时 TCP 直接关闭，UDP 不响应，避免认证 oracle 和响应放大。

响应将 Type 改为 `0x02`、更新时间戳、保留原 Nonce 和 Client ID，再对前 46 字节计算 HMAC。客户端必须校验响应类型、Nonce、Client ID、时间戳和 HMAC。

## 2. HTTP 健康探测

请求：`GET /v1/health`。禁止 query、请求体和其他 HTTP 方法。

请求头：

- `X-Probe-Client-ID`: 32 位小写十六进制 ID。
- `X-Probe-Timestamp`: Unix 秒十进制字符串。
- `X-Probe-Nonce`: 16 字节随机值的 32 位十六进制字符串。
- `X-Probe-Signature`: HMAC-SHA256 十六进制字符串。

请求签名原文为以下 UTF-8 字符串，字段间使用单个 LF（`\n`），末尾没有 LF：

```text
LGP1
GET
/v1/health
<TIMESTAMP>
<NONCE>
<SHA256_EMPTY_BODY_HEX>
```

服务端返回 JSON，并附带：

- `X-Probe-Response-Timestamp`
- `X-Probe-Response-Nonce`
- `X-Probe-Response-Signature`

响应签名原文：

```text
LGP1-RESPONSE
<HTTP_STATUS>
<TIMESTAMP>
<NONCE>
<SHA256_RESPONSE_BODY_HEX>
```

客户端必须使用相同客户端密钥验证响应签名，且确认响应 nonce 与请求 nonce 完全相同。HTTP 200 本身不能作为探测成功的充分条件。

## 3. 时间、重放和资源限制

- 请求时间与服务端时间差不得超过 120 秒。
- 同一 Client ID + Nonce 在缓存有效期内只能成功一次；缓存默认保留 3 分钟。
- 缓存达到上限且无法清理过期项时，拒绝新请求（fail-closed）。
- TCP 最大并发默认 512；每连接 8 秒 deadline。
- UDP 最大报文 78 字节；全局默认 2000 PPS，burst 500；响应大小等于请求大小。
- HTTP 最大并发默认 128；全局默认 100 请求/秒，burst 50；请求头 8 KiB。

## 4. 密钥和客户端身份

每个客户端使用独立 16 字节 Client ID 和至少 32 字节随机密钥。配置文件保存 Base64 标准编码密钥，权限必须为 0600 或更严格。密钥绝不能写入 Git、普通日志或聊天记录。
