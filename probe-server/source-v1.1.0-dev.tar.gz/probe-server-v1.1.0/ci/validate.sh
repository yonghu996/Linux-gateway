#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
cd "$ROOT"

GO_VERSION="$(go version)"
[[ "$GO_VERSION" == *'go1.27.4 '* ]] || {
  echo "需要 Go 1.27.4，当前为：$GO_VERSION" >&2
  exit 1
}

while IFS= read -r -d '' SCRIPT_FILE; do
  bash -n "$SCRIPT_FILE"
  shellcheck "$SCRIPT_FILE"
done < <(find . -type f -name '*.sh' -print0)

go test ./...
go test -race ./...
go vet ./...
GODEBUG=checkptr=2 go test ./...
go test -cover ./...
go test ./internal/protocol -run '^$' -fuzz FuzzParseFrame -fuzztime=5s
