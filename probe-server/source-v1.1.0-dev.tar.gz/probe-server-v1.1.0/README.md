# Linux Gateway Probe Server（独立探测服务器）

本项目是 Linux 多出口网关的独立探测服务端。服务端不代理业务流量，不保存代理节点账号密码；只接收经过认证的 HTTP、TCP、UDP 探测请求。

## 当前状态

- 版本：v1.1.0-dev
- 协议：LGP1（本仓库重新定义，与已删除的旧 v1.0.1 源码不保证二进制兼容）
- 目标系统：Debian 11/12、Ubuntu 20.04/22.04
- 目标架构：Linux AMD64、ARM64
- 编译工具链：Go 1.27.4
- 当前源码不应在完成 CI、漏洞扫描和真实公网验收前标记为生产版本。

## 服务接口

| 接口 | 默认监听 | 作用 |
|---|---:|---|
| HTTPS/HTTP | 127.0.0.1:8080 | 带 HMAC 的健康探测；未配置 TLS 时只允许 loopback |
| TCP | :9001 | 固定长度、HMAC 认证的 TCP Echo |
| UDP | :9002 | 固定长度、HMAC 认证的 UDP Echo |

`/healthz` 也受来源 CIDR 白名单和 HTTP 全局速率限制保护。公网部署必须启用 TLS，并在云安全组及主机防火墙限制来源。

## 安全限制

- HMAC-SHA256；客户端密钥至少 32 随机字节。
- Unix 时间戳允许偏差 120 秒。
- 16 字节随机 nonce；服务端防重放缓存默认最多 100000 条，满时 fail-closed。
- TCP 每连接只处理一个固定 78 字节请求帧，8 秒 deadline；默认最多 512 个并发连接。
- UDP 每个数据报必须恰好 78 字节；默认 2000 PPS、burst 500；响应长度不大于请求。
- HTTP 最大并发默认 128；全局速率限制 100 请求/秒、burst 50；请求头 8 KiB，并设置读写超时。
- 所有接口共享来源 CIDR 白名单；白名单为空时服务拒绝启动。
- 配置文件必须为 0600 或更严格；服务使用非 root 用户运行。
- 服务不提供远程命令、文件写入、URL 抓取或配置修改 API。

## 安装

```bash
sudo bash install.sh
```

安装脚本会检测发行版和架构，下载 Go 1.27.4 官方工具链并核验 SHA256，运行测试后构建 AMD64 产物，并安装 systemd 服务。首次安装默认只允许本机访问；不会修改防火墙、云安全组或公网监听策略。

## 首次安装后必须配置

配置文件：`/etc/linux-gateway-probe/server.json`

1. 将 `allow_cidrs` 更新为实际代理出口 IP/CIDR。必须分别纳入 HTTP、TCP、UDP 实际出口 IP；同一代理的 TCP 与 UDP 出口可能不同。节点每天轮换时，需由后续网关控制面生成并更新此清单。
2. 配置 TLS 证书和私钥，并将 `http_addr` 改为公网可达的 TLS 监听地址，例如 `:8443`。不要把明文 HTTP 8080 暴露到公网。
3. 确认私钥只允许 root 和服务组读取。
4. 在腾讯云安全组只开放实际需要的 HTTPS 8443/TCP、9001/TCP、9002/UDP，并限制来源；不要开放明文 8080。
5. 使用 SSH 安全取回 `/etc/linux-gateway-probe/client-credentials.txt`，不要将密钥粘贴到聊天、GitHub 或普通日志。
6. 配置变更后重启服务：`systemctl restart probe-server`。

首次安装生成的客户端凭据保存在 root:root、0600 文件中。配置中的客户端 ID 和密钥是独立身份；后续客户端应验证 HTTP 响应 HMAC，不能只看 HTTP 200。

## 测试

```bash
go test ./...
go test -race ./...
go vet ./...
GODEBUG=checkptr=2 go test ./...
go test -cover ./...
```

ARM64 交叉编译不等于 ARM64 实机验收。公网 DDoS 防护也不能仅依靠应用层 HMAC。
