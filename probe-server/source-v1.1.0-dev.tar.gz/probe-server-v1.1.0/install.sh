#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SERVICE='probe-server'
CONFIG_DIR='/etc/linux-gateway-probe'
BIN='/usr/local/bin/probe-server'
UNIT='/etc/systemd/system/probe-server.service'
STATE='/var/lib/linux-gateway-probe'
require_root(){ [[ ${EUID:-$(id -u)} -eq 0 ]] || { echo '请使用 root 运行。' >&2; exit 1; }; }
check_os(){
  OS_ID="$(sed -n 's/^ID=//p' /etc/os-release | head -n 1 | tr -d '"')"
  OS_VERSION="$(sed -n 's/^VERSION_ID=//p' /etc/os-release | head -n 1 | tr -d '"')"
  case "$OS_ID:$OS_VERSION" in debian:11|debian:12|ubuntu:20.04|ubuntu:22.04) ;; *) echo "暂不支持：$OS_ID $OS_VERSION" >&2; exit 1;; esac
  command -v systemctl >/dev/null && [[ -d /run/systemd/system ]] || { echo '需要 systemd 运行环境。' >&2; exit 1; }
  case "$(uname -m)" in x86_64|amd64) ;; *) echo '当前 Probe Server 版本仅支持 Linux AMD64。' >&2; exit 1;; esac
}
rollback_install(){
  echo '安装失败，正在恢复上一版本。' >&2
  if [[ -f "$STATE/rollback/probe-server.previous" ]]; then cp -a "$STATE/rollback/probe-server.previous" "$BIN"; else rm -f "$BIN"; fi
  if [[ -f "$STATE/rollback/probe-server.service.previous" ]]; then cp -a "$STATE/rollback/probe-server.service.previous" "$UNIT"; else rm -f "$UNIT"; fi
  systemctl daemon-reload || true
  if [[ "$OLD_ACTIVE" == yes ]]; then systemctl restart "$SERVICE" || true; else systemctl stop "$SERVICE" >/dev/null 2>&1 || true; systemctl disable "$SERVICE" >/dev/null 2>&1 || true; fi
}
install_server(){
  require_root; check_os
  for cmd in curl tar sha256sum install useradd getent systemctl systemd-analyze; do command -v "$cmd" >/dev/null || { echo "缺少命令：$cmd" >&2; return 1; }; done
  echo '安装计划：下载并校验 Go 1.27.4、运行测试、构建程序、创建低权限用户、准备密钥与配置、安装 systemd。'
  echo '不会修改防火墙、云安全组、默认路由、SSH 或内核。'
  read -r -p '确认继续？[y/N] ' ans; [[ "$ans" =~ ^[Yy]$ ]] || return 0

  bash "$ROOT/scripts/install-go.sh"
  (cd "$ROOT" && bash "$ROOT/scripts/build.sh")
  install -d -o root -g root -m 0755 /usr/local/bin "$CONFIG_DIR"
  install -d -o root -g root -m 0700 "$STATE/rollback"
  if ! id "$SERVICE" >/dev/null 2>&1; then
    useradd --system --home-dir "$STATE" --no-create-home --shell /usr/sbin/nologin "$SERVICE"
  else
    SERVICE_UID="$(id -u "$SERVICE")"
    SERVICE_SHELL="$(getent passwd "$SERVICE" | cut -d: -f7)"
    if [[ "$SERVICE_UID" -ge 1000 || "$SERVICE_SHELL" != /usr/sbin/nologin ]]; then
      echo '现有 probe-server 用户不是预期的系统无登录用户，拒绝继续。' >&2
      return 1
    fi
  fi
  install -d -o "$SERVICE" -g "$SERVICE" -m 0700 "$STATE"

  if [[ -L "$CONFIG_DIR/server.json" ]]; then
    echo '配置文件不能是符号链接，拒绝继续。' >&2
    return 1
  fi
  if [[ ! -f "$CONFIG_DIR/server.json" ]]; then
    KEYGEN="$ROOT/dist/probe-keygen-linux-amd64"
    read -r CLIENT_ID CLIENT_SECRET < <("$KEYGEN")
    cat > "$CONFIG_DIR/server.json" <<JSON
{
  "http_addr": "127.0.0.1:8080",
  "tls_cert_file": "",
  "tls_key_file": "",
  "tcp_addr": ":9001",
  "udp_addr": ":9002",
  "allow_cidrs": ["127.0.0.1/32"],
  "clients": {"$CLIENT_ID": {"secret_base64": "$CLIENT_SECRET"}},
  "max_tcp_connections": 512,
  "max_http_requests": 128,
  "max_replay_entries": 100000,
  "udp_packets_per_second": 2000,
  "udp_burst": 500
}
JSON
    printf 'client_id=%s\nsecret_base64=%s\n' "$CLIENT_ID" "$CLIENT_SECRET" > "$CONFIG_DIR/client-credentials.txt"
    chmod 0600 "$CONFIG_DIR/client-credentials.txt"
    chown root:root "$CONFIG_DIR/client-credentials.txt"
    echo "已生成客户端凭据：$CONFIG_DIR/client-credentials.txt（root:root 0600；请通过 SSH 安全取回，切勿发到聊天或提交 Git）"
  fi
  chown "$SERVICE:$SERVICE" "$CONFIG_DIR/server.json"
  chmod 0600 "$CONFIG_DIR/server.json"

  ARCH='amd64'
  STAGE="$BIN.new.$$"
  install -o root -g root -m 0755 "$ROOT/dist/probe-server-linux-$ARCH" "$STAGE"
  if ! "$STAGE" -config "$CONFIG_DIR/server.json" -check-config; then
    rm -f "$STAGE"
    echo '新版本配置验证失败；未替换现有服务。' >&2
    return 1
  fi

  OLD_ACTIVE=no
  if systemctl is-active --quiet "$SERVICE"; then OLD_ACTIVE=yes; fi
  if [[ -x "$BIN" ]]; then cp -a "$BIN" "$STATE/rollback/probe-server.previous"; fi
  if [[ -f "$UNIT" ]]; then cp -a "$UNIT" "$STATE/rollback/probe-server.service.previous"; fi
  mv -f "$STAGE" "$BIN"
  install -o root -g root -m 0644 "$ROOT/systemd/probe-server.service" "$UNIT"
  if ! systemd-analyze verify "$UNIT"; then rollback_install; return 1; fi
  if ! systemctl daemon-reload; then rollback_install; return 1; fi
  if ! systemctl enable "$SERVICE"; then rollback_install; return 1; fi
  if [[ "$OLD_ACTIVE" == yes ]]; then
    if ! systemctl restart "$SERVICE"; then rollback_install; return 1; fi
  else
    if ! systemctl start "$SERVICE"; then rollback_install; return 1; fi
  fi
  if ! systemctl is-active --quiet "$SERVICE"; then rollback_install; return 1; fi
  systemctl --no-pager --full status "$SERVICE"
  echo '服务已启动。当前配置默认只允许本机访问；远程接入前必须配置 TLS 和真实代理出口 IP 白名单。'
}
menu(){
  while true; do
    printf '\nLinux Gateway Probe Server\n1) 安装 / 升级\n2) 查看状态\n3) 查看日志\n4) 查看配置路径\n0) 退出\n'
    read -r -p '请选择：' c || c=0
    case "$c" in
      1) install_server ;;
      2) systemctl --no-pager status probe-server || true ;;
      3) journalctl -u probe-server -n 100 --no-pager || true ;;
      4) echo "$CONFIG_DIR/server.json" ;;
      0) exit 0 ;;
      *) echo '无效选项。' ;;
    esac
  done
}
menu "$@"
