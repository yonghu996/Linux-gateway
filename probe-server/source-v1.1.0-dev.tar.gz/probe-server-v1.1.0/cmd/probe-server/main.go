// Probe Server 主程序：加载配置、校验 TLS，并响应 SIGINT/SIGTERM。
package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/yonghu996/Linux-gateway/probe-server/internal/server"
)

func main() {
	configPath := flag.String("config", "/etc/linux-gateway-probe/server.json", "JSON configuration file")
	checkConfig := flag.Bool("check-config", false, "validate configuration and exit")
	showVersion := flag.Bool("version", false, "print version and exit")
	flag.Parse()
	if *showVersion {
		fmt.Println("probe-server v1.1.0-dev protocol=LGP1")
		return
	}
	logger := log.New(os.Stdout, "probe-server: ", log.LstdFlags|log.LUTC)
	svc, err := server.LoadAndNew(*configPath, logger)
	if err != nil {
		logger.Fatalf("configuration: %v", err)
	}
	if *checkConfig {
		if err := svc.CheckConfig(); err != nil {
			logger.Fatalf("TLS configuration: %v", err)
		}
		logger.Println("configuration valid")
		return
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	if err := svc.Run(ctx); err != nil {
		logger.Fatalf("server stopped: %v", err)
	}
}
