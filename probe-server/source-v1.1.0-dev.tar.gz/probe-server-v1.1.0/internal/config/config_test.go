package config

import (
	"os"
	"path/filepath"
	"testing"
)

func writeConfig(t *testing.T, body string, mode os.FileMode) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "server.json")
	if err := os.WriteFile(p, []byte(body), mode); err != nil {
		t.Fatal(err)
	}
	return p
}
func TestLoadValidConfig(t *testing.T) {
	body := `{"http_addr":"127.0.0.1:8080","tcp_addr":"127.0.0.1:9001","udp_addr":"127.0.0.1:9002","allow_cidrs":["127.0.0.1/32"],"clients":{"00112233445566778899aabbccddeeff":{"secret_base64":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="}}}`
	p := writeConfig(t, body, 0600)
	c, err := Load(p)
	if err != nil {
		t.Fatal(err)
	}
	if len(c.Secrets) != 1 || len(c.Secrets["00112233445566778899aabbccddeeff"]) != 32 {
		t.Fatal("client secret not loaded")
	}
}
func TestLoadRejectsWeakPermissions(t *testing.T) {
	p := writeConfig(t, `{}`, 0644)
	if _, err := Load(p); err == nil {
		t.Fatal("world-readable config accepted")
	}
}
func TestLoadRejectsInvalidClientID(t *testing.T) {
	body := `{"allow_cidrs":["127.0.0.1/32"],"clients":{"not-a-client-id":{"secret_base64":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="}}}`
	p := writeConfig(t, body, 0600)
	if _, err := Load(p); err == nil {
		t.Fatal("invalid client id accepted")
	}
}
func TestLoadRejectsShortSecret(t *testing.T) {
	body := `{"allow_cidrs":["127.0.0.1/32"],"clients":{"00112233445566778899aabbccddeeff":{"secret_base64":"c2hvcnQ="}}}`
	p := writeConfig(t, body, 0600)
	if _, err := Load(p); err == nil {
		t.Fatal("short secret accepted")
	}
}
func TestUnknownJSONFieldRejected(t *testing.T) {
	body := `{"allow_cidrs":["127.0.0.1/32"],"clients":{"00112233445566778899aabbccddeeff":{"secret_base64":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="}},"run_command":"id"}`
	p := writeConfig(t, body, 0600)
	if _, err := Load(p); err == nil {
		t.Fatal("unknown config field accepted")
	}
}

func TestLoadRejectsSymlink(t *testing.T) {
	dir := t.TempDir()
	target := filepath.Join(dir, "real.json")
	if err := os.WriteFile(target, []byte(`{}`), 0600); err != nil {
		t.Fatal(err)
	}
	link := filepath.Join(dir, "link.json")
	if err := os.Symlink(target, link); err != nil {
		t.Fatal(err)
	}
	if _, err := Load(link); err == nil {
		t.Fatal("symlink config accepted")
	}
}
