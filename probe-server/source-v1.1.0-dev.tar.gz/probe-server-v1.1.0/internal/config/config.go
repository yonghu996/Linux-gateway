// 配置包：严格解析服务端配置，并验证权限、客户端密钥和来源网段。
package config

import (
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/netip"
	"os"
	"strings"
)

type Client struct {
	Secret string `json:"secret_base64"`
}
type Config struct {
	HTTPAddr     string            `json:"http_addr"`
	TLSCert      string            `json:"tls_cert_file"`
	TLSKey       string            `json:"tls_key_file"`
	TCPAddr      string            `json:"tcp_addr"`
	UDPAddr      string            `json:"udp_addr"`
	AllowCIDRs   []string          `json:"allow_cidrs"`
	Clients      map[string]Client `json:"clients"`
	MaxTCP       int               `json:"max_tcp_connections"`
	MaxHTTP      int               `json:"max_http_requests"`
	MaxReplay    int               `json:"max_replay_entries"`
	UDPPerSecond int               `json:"udp_packets_per_second"`
	UDPBurst     int               `json:"udp_burst"`
}

type Loaded struct {
	Config
	Secrets  map[string][]byte
	Networks []netip.Prefix
}

func Load(path string) (*Loaded, error) {
	st, err := os.Lstat(path)
	if err != nil {
		return nil, err
	}
	if !st.Mode().IsRegular() {
		return nil, errors.New("config must be a regular file; symlinks are not allowed")
	}
	if st.Mode().Perm()&0077 != 0 {
		return nil, fmt.Errorf("config permissions must be 0600 or stricter; got %04o", st.Mode().Perm())
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var c Config
	dec := json.NewDecoder(strings.NewReader(string(b)))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&c); err != nil {
		return nil, err
	}
	var extra any
	if err := dec.Decode(&extra); err != io.EOF {
		return nil, errors.New("config must contain exactly one JSON document")
	}
	if c.HTTPAddr == "" {
		c.HTTPAddr = "127.0.0.1:8080"
	}
	if c.TCPAddr == "" {
		c.TCPAddr = ":9001"
	}
	if c.UDPAddr == "" {
		c.UDPAddr = ":9002"
	}
	if c.MaxTCP == 0 {
		c.MaxTCP = 512
	}
	if c.MaxHTTP == 0 {
		c.MaxHTTP = 128
	}
	if c.MaxReplay == 0 {
		c.MaxReplay = 100000
	}
	if c.UDPPerSecond == 0 {
		c.UDPPerSecond = 2000
	}
	if c.UDPBurst == 0 {
		c.UDPBurst = 500
	}
	if c.MaxTCP < 1 || c.MaxTCP > 4096 || c.MaxHTTP < 1 || c.MaxHTTP > 1024 || c.MaxReplay < 100 || c.MaxReplay > 1000000 || c.UDPPerSecond < 1 || c.UDPPerSecond > 100000 || c.UDPBurst < 1 || c.UDPBurst > 10000 {
		return nil, errors.New("configured resource limit out of allowed range")
	}
	if (c.TLSCert == "") != (c.TLSKey == "") {
		return nil, errors.New("tls_cert_file and tls_key_file must be configured together")
	}
	out := &Loaded{Config: c, Secrets: map[string][]byte{}}
	for id, cl := range c.Clients {
		if len(id) != 32 {
			return nil, fmt.Errorf("client id %q must be 32 hex characters", id)
		}
		if strings.ToLower(id) != id {
			return nil, fmt.Errorf("client id %q must use lowercase hex", id)
		}
		if _, err := hex.DecodeString(id); err != nil {
			return nil, fmt.Errorf("invalid client id %q", id)
		}
		sec, err := base64.StdEncoding.DecodeString(cl.Secret)
		if err != nil || len(sec) < 32 {
			return nil, fmt.Errorf("client %s secret must be base64 and at least 32 bytes", id)
		}
		out.Secrets[id] = sec
	}
	if len(out.Secrets) == 0 {
		return nil, errors.New("at least one client must be configured")
	}
	for _, s := range c.AllowCIDRs {
		p, err := netip.ParsePrefix(s)
		if err != nil {
			return nil, fmt.Errorf("invalid allow_cidr %q", s)
		}
		out.Networks = append(out.Networks, p.Masked())
	}
	return out, nil
}
