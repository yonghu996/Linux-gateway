package protocol

import (
	"bytes"
	"testing"
	"time"
)

func TestFrameRoundTripAndHMAC(t *testing.T) {
	key := bytes.Repeat([]byte{0x42}, 32)
	f := Frame{Type: TypeRequest, Timestamp: time.Now().Unix()}
	copy(f.Nonce[:], bytes.Repeat([]byte{0x11}, 16))
	copy(f.ClientID[:], bytes.Repeat([]byte{0x22}, 16))
	Sign(&f, key)
	raw := f.Bytes()
	parsed, err := Parse(raw)
	if err != nil {
		t.Fatal(err)
	}
	if !Verify(parsed, key) {
		t.Fatal("valid signature rejected")
	}
	raw[20] ^= 1
	parsed, err = Parse(raw)
	if err != nil {
		t.Fatal(err)
	}
	if Verify(parsed, key) {
		t.Fatal("tampered frame accepted")
	}
}
func TestFrameRejectsLengthAndMagic(t *testing.T) {
	if _, err := Parse(make([]byte, FrameSize-1)); err == nil {
		t.Fatal("short frame accepted")
	}
	b := make([]byte, FrameSize)
	if _, err := Parse(b); err == nil {
		t.Fatal("bad magic accepted")
	}
}
func TestFreshTimestamp(t *testing.T) {
	now := time.Now()
	if !Fresh(now.Unix(), now) {
		t.Fatal("current timestamp rejected")
	}
	if Fresh(now.Add(-MaxClockSkew-time.Second).Unix(), now) {
		t.Fatal("stale timestamp accepted")
	}
}

func FuzzParseFrame(f *testing.F) {
	seed := Frame{Type: TypeRequest, Timestamp: time.Now().Unix()}.Bytes()
	f.Add(seed)
	f.Add([]byte("LGP1"))
	f.Fuzz(func(t *testing.T, raw []byte) {
		parsed, err := Parse(raw)
		if err != nil {
			return
		}
		encoded := parsed.Bytes()
		reparsed, err := Parse(encoded)
		if err != nil {
			t.Fatalf("roundtrip parse failed: %v", err)
		}
		if reparsed != parsed {
			t.Fatal("frame roundtrip changed data")
		}
	})
}
