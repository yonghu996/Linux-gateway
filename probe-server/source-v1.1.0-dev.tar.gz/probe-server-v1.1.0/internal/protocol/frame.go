// 协议包：定义 LGP1 固定长度 TCP/UDP 探测帧及 HMAC 认证。
package protocol

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"time"
)

const (
	FrameSize    = 78
	HeaderSize   = 46
	Version      = 1
	TypeRequest  = 1
	TypeResponse = 2
	Magic        = "LGP1"
	MaxClockSkew = 120 * time.Second
)

type Frame struct {
	Type      byte
	Timestamp int64
	Nonce     [16]byte
	ClientID  [16]byte
	MAC       [32]byte
}

func (f Frame) Bytes() []byte {
	b := make([]byte, FrameSize)
	copy(b[:4], Magic)
	b[4] = Version
	b[5] = f.Type
	if f.Timestamp > 0 {
		binary.BigEndian.PutUint64(b[6:14], uint64(f.Timestamp))
	}
	copy(b[14:30], f.Nonce[:])
	copy(b[30:46], f.ClientID[:])
	copy(b[46:78], f.MAC[:])
	return b
}
func Parse(b []byte) (Frame, error) {
	var f Frame
	if len(b) != FrameSize || string(b[:4]) != Magic || b[4] != Version || (b[5] != TypeRequest && b[5] != TypeResponse) {
		return f, errors.New("invalid frame")
	}
	f.Type = b[5]
	rawTimestamp := binary.BigEndian.Uint64(b[6:14])
	if rawTimestamp > uint64(1<<63-1) {
		return f, errors.New("invalid timestamp")
	}
	f.Timestamp = int64(rawTimestamp)
	copy(f.Nonce[:], b[14:30])
	copy(f.ClientID[:], b[30:46])
	copy(f.MAC[:], b[46:78])
	return f, nil
}
func Sign(f *Frame, key []byte) {
	f.MAC = [32]byte{}
	raw := f.Bytes()
	m := hmac.New(sha256.New, key)
	m.Write(raw[:HeaderSize])
	copy(f.MAC[:], m.Sum(nil))
}
func Verify(f Frame, key []byte) bool {
	got := f.MAC
	f.MAC = [32]byte{}
	raw := f.Bytes()
	m := hmac.New(sha256.New, key)
	m.Write(raw[:HeaderSize])
	return hmac.Equal(got[:], m.Sum(nil))
}
func Fresh(ts int64, now time.Time) bool {
	d := now.Sub(time.Unix(ts, 0))
	if d < 0 {
		d = -d
	}
	return d <= MaxClockSkew
}
