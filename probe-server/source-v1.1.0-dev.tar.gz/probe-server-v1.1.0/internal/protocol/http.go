// HTTP 协议：严格校验请求形状，并对请求与响应分别计算 HMAC。
package protocol

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"
)

func HTTPRequestMAC(method, path, ts, nonce string, key []byte) string {
	empty := sha256.Sum256(nil)
	canonical := strings.Join([]string{"LGP1", method, path, ts, nonce, hex.EncodeToString(empty[:])}, "\n")
	m := hmac.New(sha256.New, key)
	m.Write([]byte(canonical))
	return hex.EncodeToString(m.Sum(nil))
}
func VerifyHTTPRequest(r *http.Request, key []byte, now time.Time) (string, error) {
	single := func(name string) string {
		values := r.Header.Values(name)
		if len(values) != 1 {
			return ""
		}
		return values[0]
	}
	if r.Method != "GET" || r.URL.Path != "/v1/health" || r.RequestURI != "/v1/health" || r.URL.RawPath != "" || r.URL.RawQuery != "" || len(r.TransferEncoding) != 0 || r.ContentLength != 0 || (r.Body != nil && r.Body != http.NoBody) {
		return "", fmt.Errorf("invalid request shape")
	}
	ts := single("X-Probe-Timestamp")
	nonce := single("X-Probe-Nonce")
	sig := single("X-Probe-Signature")
	clientID := single("X-Probe-Client-ID")
	if len(clientID) != 32 || strings.ToLower(clientID) != clientID {
		return "", fmt.Errorf("invalid client id")
	}
	if _, err := hex.DecodeString(clientID); err != nil {
		return "", fmt.Errorf("invalid client id")
	}
	if len(nonce) != 32 || strings.ToLower(nonce) != nonce {
		return "", fmt.Errorf("nonce must be 32 lowercase hexadecimal characters")
	}
	if _, err := hex.DecodeString(nonce); err != nil {
		return "", fmt.Errorf("invalid nonce")
	}
	if ts == "" || strings.Trim(ts, "0123456789") != "" {
		return "", fmt.Errorf("invalid timestamp")
	}
	n, err := strconv.ParseInt(ts, 10, 64)
	if err != nil || !Fresh(n, now) {
		return "", fmt.Errorf("stale timestamp")
	}
	expected := HTTPRequestMAC(r.Method, r.URL.Path, ts, nonce, key)
	if !hmac.Equal([]byte(strings.ToLower(sig)), []byte(expected)) {
		return "", fmt.Errorf("invalid signature")
	}
	return nonce, nil
}
func HTTPResponseMAC(status int, ts, nonce string, body []byte, key []byte) string {
	sum := sha256.Sum256(body)
	canonical := fmt.Sprintf("LGP1-RESPONSE\n%d\n%s\n%s\n%s", status, ts, nonce, hex.EncodeToString(sum[:]))
	m := hmac.New(sha256.New, key)
	m.Write([]byte(canonical))
	return hex.EncodeToString(m.Sum(nil))
}
