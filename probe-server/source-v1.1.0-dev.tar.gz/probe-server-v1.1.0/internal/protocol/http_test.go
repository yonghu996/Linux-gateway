package protocol

import (
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestHTTPAuthAndBodyRejection(t *testing.T) {
	key := []byte(strings.Repeat("k", 32))
	now := time.Now()
	ts := fmtInt(now.Unix())
	nonce := "00112233445566778899aabbccddeeff"
	req := httptest.NewRequest("GET", "/v1/health", nil)
	req.Header.Set("X-Probe-Client-ID", "00112233445566778899aabbccddeeff")
	req.Header.Set("X-Probe-Timestamp", ts)
	req.Header.Set("X-Probe-Nonce", nonce)
	req.Header.Set("X-Probe-Signature", HTTPRequestMAC("GET", "/v1/health", ts, nonce, key))
	got, err := VerifyHTTPRequest(req, key, now)
	if err != nil || got != nonce {
		t.Fatalf("valid request rejected: %v", err)
	}
	bodyReq := httptest.NewRequest("GET", "/v1/health", strings.NewReader("body"))
	bodyReq.Header = req.Header.Clone()
	if _, err := VerifyHTTPRequest(bodyReq, key, now); err == nil {
		t.Fatal("GET body accepted")
	}
	queryReq := httptest.NewRequest("GET", "/v1/health?x=1", nil)
	queryReq.Header = req.Header.Clone()
	if _, err := VerifyHTTPRequest(queryReq, key, now); err == nil {
		t.Fatal("query accepted")
	}
}
func TestHTTPResponseSignatureChangesWithBody(t *testing.T) {
	key := []byte(strings.Repeat("k", 32))
	sig := HTTPResponseMAC(200, "1", "abc", []byte("ok"), key)
	if sig == HTTPResponseMAC(200, "1", "abc", []byte("bad"), key) {
		t.Fatal("response signature did not bind body")
	}
}
func fmtInt(v int64) string { return strconv.FormatInt(v, 10) }
