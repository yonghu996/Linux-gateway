package protocol

import (
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestHTTPAuthAndBodyRejection(t *testing.T) {
	key := []byte(strings.Repeat("k", 32))
	now := time.Now()
	ts := fmtInt(now.Unix())
	nonce := "00112233445566778899aabbccddeeff"
	req := httptest.NewRequest("GET", "/v1/health", nil)
	req.Header.Set("X-Probe-Client-ID", "00112233445566778899aabbccddeeff")
	req.Header.Set("X-Probe-Timestamp", ts)
	req.Header.Set("X-Probe-Nonce", nonce)
	req.Header.Set("X-Probe-Signature", HTTPRequestMAC("GET", "/v1/health", ts, nonce, key))
	got, err := VerifyHTTPRequest(req, key, now)
	if err != nil || got != nonce {
		t.Fatalf("valid request rejected: %v", err)
	}
	bodyReq := httptest.NewRequest("GET", "/v1/health", strings.NewReader("body"))
	bodyReq.Header = req.Header.Clone()
	if _, err := VerifyHTTPRequest(bodyReq, key, now); err == nil {
		t.Fatal("GET body accepted")
	}
	queryReq := httptest.NewRequest("GET", "/v1/health?x=1", nil)
	queryReq.Header = req.Header.Clone()
	if _, err := VerifyHTTPRequest(queryReq, key, now); err == nil {
		t.Fatal("query accepted")
	}
}
func TestHTTPResponseSignatureChangesWithBody(t *testing.T) {
	key := []byte(strings.Repeat("k", 32))
	sig := HTTPResponseMAC(200, "1", "abc", []byte("ok"), key)
	if sig == HTTPResponseMAC(200, "1", "abc", []byte("bad"), key) {
		t.Fatal("response signature did not bind body")
	}
}
func fmtInt(v int64) string { return strconv.FormatInt(v, 10) }

func TestHTTPRejectsEscapedPathAndChunkedBody(t *testing.T) {
	key := []byte(strings.Repeat("k", 32))
	now := time.Now()
	ts := fmtInt(now.Unix())
	nonce := "00112233445566778899aabbccddeeff"
	headers := func() http.Header {
		h := make(http.Header)
		h.Set("X-Probe-Client-ID", "00112233445566778899aabbccddeeff")
		h.Set("X-Probe-Timestamp", ts)
		h.Set("X-Probe-Nonce", nonce)
		h.Set("X-Probe-Signature", HTTPRequestMAC("GET", "/v1/health", ts, nonce, key))
		return h
	}
	pathReq := httptest.NewRequest("GET", "/v1/%68ealth", nil)
	pathReq.Header = headers()
	if _, err := VerifyHTTPRequest(pathReq, key, now); err == nil {
		t.Fatal("escaped request path accepted")
	}
	chunkedReq := httptest.NewRequest("GET", "/v1/health", strings.NewReader("x"))
	chunkedReq.Header = headers()
	chunkedReq.TransferEncoding = []string{"chunked"}
	chunkedReq.ContentLength = -1
	if _, err := VerifyHTTPRequest(chunkedReq, key, now); err == nil {
		t.Fatal("chunked GET body accepted")
	}
}
