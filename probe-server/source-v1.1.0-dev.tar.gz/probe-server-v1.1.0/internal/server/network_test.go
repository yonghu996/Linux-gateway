package server

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"io"
	"log"
	"net"
	"net/netip"
	"testing"
	"time"

	"github.com/yonghu996/Linux-gateway/probe-server/internal/config"
	"github.com/yonghu996/Linux-gateway/probe-server/internal/protocol"
)

func networkTestService(t *testing.T) *Service {
	t.Helper()
	key := make([]byte, 32)
	if _, err := rand.Read(key); err != nil {
		t.Fatal(err)
	}
	id := "00112233445566778899aabbccddeeff"
	c := &config.Loaded{Config: config.Config{MaxReplay: 100, MaxTCP: 4, MaxHTTP: 4, UDPPerSecond: 100, UDPBurst: 20}, Secrets: map[string][]byte{id: key}, Networks: []netip.Prefix{netip.MustParsePrefix("127.0.0.1/32")}}
	return New(c, log.New(io.Discard, "", 0))
}
func requestFrame(t *testing.T, s *Service) protocol.Frame {
	t.Helper()
	id, _ := hex.DecodeString("00112233445566778899aabbccddeeff")
	var f protocol.Frame
	f.Type = protocol.TypeRequest
	f.Timestamp = time.Now().Unix()
	_, _ = rand.Read(f.Nonce[:])
	copy(f.ClientID[:], id)
	protocol.Sign(&f, s.cfg.Secrets[hex.EncodeToString(id)])
	return f
}
func verifyNetworkResponse(t *testing.T, s *Service, raw []byte, req protocol.Frame) {
	t.Helper()
	resp, err := protocol.Parse(raw)
	if err != nil {
		t.Fatal(err)
	}
	if resp.Type != protocol.TypeResponse {
		t.Fatal("wrong response type")
	}
	if resp.Nonce != req.Nonce || resp.ClientID != req.ClientID {
		t.Fatal("response does not bind request nonce/client")
	}
	if !protocol.Verify(resp, s.cfg.Secrets[hex.EncodeToString(req.ClientID[:])]) {
		t.Fatal("invalid response signature")
	}
}
func TestTCPAuthenticatedEcho(t *testing.T) {
	s := networkTestService(t)
	ln, err := net.ListenTCP("tcp", &net.TCPAddr{IP: net.ParseIP("127.0.0.1"), Port: 0})
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- s.serveTCPListener(ctx, ln) }()
	c, err := net.DialTimeout("tcp", ln.Addr().String(), time.Second)
	if err != nil {
		cancel()
		t.Fatal(err)
	}
	_ = c.SetDeadline(time.Now().Add(2 * time.Second))
	req := requestFrame(t, s)
	if _, err = c.Write(req.Bytes()); err != nil {
		t.Fatal(err)
	}
	resp := make([]byte, protocol.FrameSize)
	if _, err = io.ReadFull(c, resp); err != nil {
		t.Fatal(err)
	}
	verifyNetworkResponse(t, s, resp, req)
	_ = c.Close()
	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("TCP listener did not stop")
	}
}
func TestUDPAuthenticatedEcho(t *testing.T) {
	s := networkTestService(t)
	conn, err := net.ListenUDP("udp", &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: 0})
	if err != nil {
		t.Fatal(err)
	}
	addr := conn.LocalAddr().(*net.UDPAddr)
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- s.serveUDPConn(ctx, conn) }()
	c, err := net.DialUDP("udp", nil, addr)
	if err != nil {
		cancel()
		t.Fatal(err)
	}
	defer c.Close()
	_ = c.SetDeadline(time.Now().Add(2 * time.Second))
	req := requestFrame(t, s)
	if _, err = c.Write(req.Bytes()); err != nil {
		t.Fatal(err)
	}
	resp := make([]byte, protocol.FrameSize+1)
	n, err := c.Read(resp)
	if err != nil {
		t.Fatal(err)
	}
	if n != protocol.FrameSize {
		t.Fatalf("unexpected UDP response size %d", n)
	}
	verifyNetworkResponse(t, s, resp[:n], req)
	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("UDP listener did not stop")
	}
}
