// 限制 HTTP 已接受连接数，避免大量空闲连接耗尽文件描述符。
package server

import (
	"net"
	"sync"
)

type limitListener struct {
	net.Listener
	slots chan struct{}
	done  chan struct{}
	once  sync.Once
}

func newLimitListener(inner net.Listener, max int) *limitListener {
	return &limitListener{Listener: inner, slots: make(chan struct{}, max), done: make(chan struct{})}
}
func (l *limitListener) Accept() (net.Conn, error) {
	select {
	case l.slots <- struct{}{}:
	case <-l.done:
		return nil, net.ErrClosed
	}
	c, err := l.Listener.Accept()
	if err != nil {
		<-l.slots
		return nil, err
	}
	return &limitedConn{Conn: c, release: func() { <-l.slots }}, nil
}
func (l *limitListener) Close() error { l.once.Do(func() { close(l.done) }); return l.Listener.Close() }

type limitedConn struct {
	net.Conn
	once    sync.Once
	release func()
}

func (c *limitedConn) Close() error { err := c.Conn.Close(); c.once.Do(c.release); return err }
