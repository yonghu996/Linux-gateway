package server

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"net/http/httptest"
	"net/netip"
	"strings"
	"testing"
	"time"

	"github.com/yonghu996/Linux-gateway/probe-server/internal/config"
	"github.com/yonghu996/Linux-gateway/probe-server/internal/protocol"
)

func testService(t *testing.T) *Service {
	t.Helper()
	secret := make([]byte, 32)
	if _, err := rand.Read(secret); err != nil {
		t.Fatal(err)
	}
	id := "00112233445566778899aabbccddeeff"
	c := &config.Loaded{Config: config.Config{MaxReplay: 100, MaxTCP: 2, MaxHTTP: 2, UDPPerSecond: 10, UDPBurst: 10}, Secrets: map[string][]byte{id: secret}}
	// Allow loopback for the httptest remote address.
	c.Networks = []netip.Prefix{netip.MustParsePrefix("127.0.0.1/32")}
	_ = base64.StdEncoding.EncodeToString(secret)
	return New(c, nil)
}
func TestHTTPHealthSignedAndReplayRejected(t *testing.T) {
	s := testService(t)
	id := "00112233445566778899aabbccddeeff"
	key := s.cfg.Secrets[id]
	nonceBytes := make([]byte, 16)
	_, _ = rand.Read(nonceBytes)
	nonce := hex.EncodeToString(nonceBytes)
	ts := fmt.Sprintf("%d", time.Now().Unix())
	makeReq := func() *httptest.ResponseRecorder {
		r := httptest.NewRequest("GET", "/v1/health", nil)
		r.RemoteAddr = "127.0.0.1:12345"
		r.Header.Set("X-Probe-Client-ID", id)
		r.Header.Set("X-Probe-Timestamp", ts)
		r.Header.Set("X-Probe-Nonce", nonce)
		r.Header.Set("X-Probe-Signature", protocol.HTTPRequestMAC("GET", "/v1/health", ts, nonce, key))
		w := httptest.NewRecorder()
		s.HTTPHandler().ServeHTTP(w, r)
		return w
	}
	first := makeReq()
	if first.Code != 200 {
		t.Fatalf("expected 200, got %d: %s", first.Code, first.Body.String())
	}
	if first.Header().Get("X-Probe-Response-Signature") == "" {
		t.Fatal("missing response signature")
	}
	second := makeReq()
	if second.Code != 409 {
		t.Fatalf("replay expected 409, got %d", second.Code)
	}
}
func TestHTTPRejectsUntrustedSource(t *testing.T) {
	s := testService(t)
	r := httptest.NewRequest("GET", "/healthz", nil)
	r.RemoteAddr = "192.0.2.10:1234"
	w := httptest.NewRecorder()
	s.HTTPHandler().ServeHTTP(w, r)
	if w.Code != 403 {
		t.Fatalf("expected 403, got %d", w.Code)
	}
}
func TestHTTPRejectsInvalidSignature(t *testing.T) {
	s := testService(t)
	id := "00112233445566778899aabbccddeeff"
	r := httptest.NewRequest("GET", "/v1/health", strings.NewReader(""))
	r.RemoteAddr = "127.0.0.1:1234"
	r.Header.Set("X-Probe-Client-ID", id)
	r.Header.Set("X-Probe-Timestamp", fmt.Sprintf("%d", time.Now().Unix()))
	r.Header.Set("X-Probe-Nonce", "00112233445566778899aabbccddeeff")
	r.Header.Set("X-Probe-Signature", strings.Repeat("0", 64))
	w := httptest.NewRecorder()
	s.HTTPHandler().ServeHTTP(w, r)
	if w.Code != 401 {
		t.Fatalf("expected 401, got %d", w.Code)
	}
}

func TestCheckConfigRejectsPublicPlainHTTP(t *testing.T) {
	s := testService(t)
	s.cfg.HTTPAddr = ":8080"
	if err := s.CheckConfig(); err == nil {
		t.Fatal("public plaintext HTTP accepted")
	}
}
func TestCheckConfigRequiresCIDR(t *testing.T) {
	s := testService(t)
	s.cfg.Networks = nil
	if err := s.CheckConfig(); err == nil {
		t.Fatal("empty source allowlist accepted")
	}
}
