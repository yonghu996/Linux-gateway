# 更新记录

## v1.1.0-dev（LGP1）

- 重新实现 HTTP、TCP、UDP 认证探测服务。
- 统一使用 HMAC-SHA256、时间戳和随机 nonce 防重放。
- 加入来源 CIDR 白名单、并发限制、速率限制和 systemd 权限隔离。
- 本开发版本明确只支持 Linux AMD64；不提供 ARM64 构建或安装分支。
- 生产部署仍须通过 Go 1.27.4 CI、govulncheck、gosec、真实公网验收和第三方审核。
